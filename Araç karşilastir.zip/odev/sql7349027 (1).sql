-- phpMyAdmin SQL Dump
-- version 4.7.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: sql7.freemysqlhosting.net
-- Üretim Zamanı: 20 Haz 2020, 10:56:21
-- Sunucu sürümü: 5.5.62-0ubuntu0.14.04.1
-- PHP Sürümü: 7.0.33-0ubuntu0.16.04.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `sql7349027`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `arac_tbl`
--

CREATE TABLE `arac_tbl` (
  `id` int(11) NOT NULL,
  `marka` varchar(250) NOT NULL,
  `model` varchar(250) NOT NULL,
  `km` varchar(250) NOT NULL,
  `yil` varchar(150) NOT NULL,
  `renk` varchar(250) NOT NULL,
  `plaka` varchar(250) NOT NULL,
  `fiyat` varchar(100) NOT NULL,
  `resim` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `arac_tbl`
--

INSERT INTO `arac_tbl` (`id`, `marka`, `model`, `km`, `yil`, `renk`, `plaka`, `fiyat`, `resim`) VALUES
(13, 'bmw', 'm5', '15,000', '2015', 'kÄ±rmÄ±zÄ±', '34ht7003', '100.000tl', ''),
(14, 'Reno', 'fluance', '15,000', '2015', 'siyah', '34km853', '45.000tl', 0x696e6465786c6f676f2e706e67),
(15, 'pejo', '306', '150,000', '2008', 'mavi', '34lm1258', '10,000', 0x696e6465786c6f676f2e706e67);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kayitol_tbl`
--

CREATE TABLE `kayitol_tbl` (
  `id` int(11) NOT NULL,
  `adi` varchar(250) NOT NULL,
  `soyadi` varchar(250) NOT NULL,
  `mail` varchar(250) NOT NULL,
  `sifre` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `kayitol_tbl`
--

INSERT INTO `kayitol_tbl` (`id`, `adi`, `soyadi`, `mail`, `sifre`) VALUES
(1, 'ali', 'tÃ¼redi', 'mertturedi90@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kayit_tbl`
--

CREATE TABLE `kayit_tbl` (
  `id` int(11) NOT NULL,
  `adi` varchar(250) NOT NULL,
  `soyadi` varchar(250) NOT NULL,
  `mail` text NOT NULL,
  `sifre` varchar(150) NOT NULL,
  `kod` varchar(50) NOT NULL,
  `aktivasyon` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `kayit_tbl`
--

INSERT INTO `kayit_tbl` (`id`, `adi`, `soyadi`, `mail`, `sifre`, `kod`, `aktivasyon`) VALUES
(1, 'yeter', 'Ã§iÃ§ek', 'sinana@gmail.com', '1234', '2723d092b63885e0d7c260cc007e8b9d', 0);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `arac_tbl`
--
ALTER TABLE `arac_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `kayitol_tbl`
--
ALTER TABLE `kayitol_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `kayit_tbl`
--
ALTER TABLE `kayit_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `arac_tbl`
--
ALTER TABLE `arac_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- Tablo için AUTO_INCREMENT değeri `kayitol_tbl`
--
ALTER TABLE `kayitol_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- Tablo için AUTO_INCREMENT değeri `kayit_tbl`
--
ALTER TABLE `kayit_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
