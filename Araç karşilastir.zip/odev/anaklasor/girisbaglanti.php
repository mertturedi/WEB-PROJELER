<?php 
session_start();

// Connection data (server_address, database, name, poassword)
$servername ="sql7.freemysqlhosting.net";
$username ="sql7349027";
$password ="dHLfLuhjp8";
$dbname="sql7349027";

$connect = new mysqli ($servername,$username,$password,$dbname);

// if ($connect->connect_error) {
//     die("bağlantı hatası oluştu");
// }


if($_POST){
if (!empty($_POST["mail"]) && !empty($_POST["pass"])) {
     
    
$mail =$_POST["mail"];
$pass =$_POST["pass"];
$giris="select * from kayitol_tbl where mail='$mail'and sifre='$pass' ";
$getir = $connect->query($giris);
    if ($getir->num_rows>0) {
        while ($row = $getir->fetch_assoc()) {
            $_SESSION["id"] = $row["id"];
         header("location:anasayfa.php");
        }
    }else { 
        echo "
              <script type='text/javascript'>  
              alert('Lütfen Alanları Kontrol Ediniz Şifre Veya Mail Hatalı.');
              </script>";
              
           
    }
}else{
    echo("Lütfen Alnları Doldurunuz");
}
}


    
    
    







?>