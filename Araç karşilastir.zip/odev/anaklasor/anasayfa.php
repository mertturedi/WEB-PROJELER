<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="\eklentiler\anasayfa.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
<div class=üstkutu>
  <div class = sayfaortalama>
     
  <div class="nav">
     <ul>
       <li class="active">
         
          <a href="arackayit.php"style="
        position: relative;
        left: 50px;
        ">Araç Kaydet</a>
       </li>
       <li>
          <a href="aracsil.php"style="
        position: relative;
        left: 50px;
        ">Araç Sil</a>
       </li>
       <li>
          <a href="aracguncelle.php"style="
        position: relative;
        left: 50px;
        ">Araç Güncelle</a>
       </li>
       
       <li>
       <a href="index.php" style="
        position: relative;
        left: 700px;
        ">ÇIKIŞ</a>
       </li>
     </ul>
     
      <?php
  $servername ="sql7.freemysqlhosting.net";
  $username ="sql7349027";
  $password ="dHLfLuhjp8";
  $dbname="sql7349027";
    $conn = new mysqli($servername, $username, $password, $dbname, 3306);
    $sonuc = $conn->query("SELECT * FROM arac_tbl");
    ?>


<?php

$servername ="sql7.freemysqlhosting.net";
$username ="sql7349027";
$password ="dHLfLuhjp8";
$dbname="sql7349027";

  $conn = new mysqli($servername, $username, $password, $dbname, 3306);
  if (isset($_POST["btnara"])) {
   $plaka =$_POST["plaka"];
   $sonuc = $conn->query("SELECT * FROM arac_tbl where marka='$plaka' or plaka='$plaka'or yil='$plaka'or renk='$plaka'or model='$plaka'or fiyat='$plaka'or km='$plaka'");
  }else {

      $sonuc = $conn->query("SELECT * FROM arac_tbl");
  }

  ?>







    
    <div class="container m-5">
    <form method="POST">
    <div class="main">
  
 
  <!-- Another variation with a button -->
  <div class="input-group">
    <input type="text" class="form-control" placeholder="Özellik"name="plaka">
    <div class="input-group-append">
      <button class="btn btn-secondary" type="submit" name="btnara">
        <i class="fa fa-search"></i>
      </button>
    </div>
  </div>
  

  
</div>
     </form>
        <?php for ($i = 0; $i < $sonuc->num_rows; $i++) { ?>
            <?php $row = $sonuc->fetch_row() ?>
  
            <ul class="list-group mb-3">
                <li class="list-group-item" style="color: black;
    /* size: 15px; */
    font-size: 25px;
    border: solid 1px;">
    <p>Sırası :   <?= $row[0] ?></p>
                  
                </li>
                <li class="list-group-item" style="color: black;
    /* size: 15px; */
    font-size: 25px;
    border: solid 1px;">
                   <p>Markası :   <?= $row[1] ?></p>
                </li>
                <li class="list-group-item" style="color: black;
    /* size: 15px; */
    font-size: 25px;
    border: solid 1px;">
                    <p>Modeli :   <?= $row[2] ?></p>
                </li>
                <li class="list-group-item" style="color: black;
    /* size: 15px; */
    font-size: 25px;
    border: solid 1px;">
                    <p>Km :   <?= $row[3] ?></p>
                </li>
                <li class="list-group-item" style="color: black;
    /* size: 15px; */
    font-size: 25px;
    border: solid 1px;">
                   <p>Model Yilı :   <?= $row[4] ?></p>
                </li>
                <li class="list-group-item" style="color: black;
    /* size: 15px; */
    font-size: 25px;
    border: solid 1px;">
                   <p>Renk :   <?= $row[5] ?></p>
                </li>
                <li class="list-group-item" style="color: black;
    /* size: 15px; */
    font-size: 25px;
    border: solid 1px;">
                   <p>Plaka :   <?= $row[6] ?></p>
                </li>
                <li class="list-group-item" style="color: black;
    /* size: 15px; */
    font-size: 25px;
    border: solid 1px;">
                    <p>Fiyat :   <?= $row[7] ?></p>
                </li>
                <li class="list-group-item" style="color: black;
    /* size: 15px; */
    font-size: 25px;
    border: solid 1px;">
                    <p>Resim :   <?= $row[8] ?></p>
                </li>
            </ul>

        <?php } ?>
        
     <div class="borderof"></div>
  </div> 

</body>
</html>