<?php include "girisbaglanti.php"?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="\eklentiler\giris.css">
</head>
<body>





    <div class="login-page">
    <form action="girisbaglanti.php" method ="Post">
    <div class ="kaydol">
 <p >GİRİŞ YAP</p></div>
    
        <div class="form">
          <form class="login-form">
            <input type="text" placeholder="Mail" name = "mail"/>
            <input type="text" placeholder="Şifre" name="pass"/>
            <button>Giriş Yap</button>
            <p class="message">Hesap Oluştur <a href="index.php">Kayıt Ol</a></p>
            
            
          </form>
        </div>
        </form>



      </div>
</body>
</html>
