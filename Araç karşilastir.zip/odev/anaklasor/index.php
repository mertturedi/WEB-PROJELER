<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="\eklentiler\index.css">
</head>
<body>



<div class=üstkutu>
  <div class = sayfaortalama>
     
  <div class="nav">
     <ul>
       <li class="active">
         
          <a href="giris.php">Anasayfa</a>
       </li>
       <li>
          <a href="giris.php">Araç Ekle</a>
       </li>
       <li>
          <a href="giris.php">Araç Sil</a>
       </li>
       <li>
          <a href="giris.php">Araç Bul</a>
       </li>
       
     </ul>
     <div class="borderof"></div>
  </div>
<div class="kayitresim">
<img src="https://i.hizliresim.com/U51j9X.png" alt="" srcset="" style="
    position: relative;
    top: 70px;
    left:0px;
    height: 460px;
">
</div>
  </div>
</div>


<div class=sayfaortalama>
    <div class="login-page">

    <form action="islemler.php" method ="post">
      <div class ="kaydol">
 <p >HEMEN KAYDOL</p>

      </div>
   
        <div class="form">
          <form class="login-form">
            <input type="text" placeholder="Adı" name ="AD"/>
            <input type="text" placeholder="Soyadı" name="SOYAD"/>
            <input type="text" placeholder="Mail" name = "email"/>
            <input type="text" placeholder="Şifre" name="sifre"/>
            <input type="text" placeholder="Şifre Tekrar" name="sifre2"/>
            <button>Kaydol</button>
            <p class="message">Zaten Bir Hesabım var <a href="giris.php">Giriş Yap</a></p>
          </form>
        </div>
        </form>



      </div>
      </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>


</body>
</html>
