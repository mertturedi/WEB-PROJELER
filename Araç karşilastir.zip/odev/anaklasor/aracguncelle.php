<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="\eklentiler\arackayit.css">
</head>
<body>




<div class="login-page">
    <form action="aracguncellebaglanti.php" method ="Post">
    <div class ="kaydol">
 <p >ARAÇ GÜNCELLE</p></div>
    
        <div class="form">
          <form class="login-form">
            
            <input type="text" placeholder="Güncellenecek Aracın Plakası" name="plaka"/>
            <input type="text" placeholder="Güncel KM" name="km"/>
            <input type="text" placeholder="Güncel Fiyat" name="fiyat"/>
            
            <button>Güncelle</button>
            <p class="message">Anasayfaya<a href="anasayfa.php"> Dön</a></p>
            
            
          </form>
        </div>
        </form>



      </div>
</body>
</html>