<?php 


// Connection data (server_address, database, name, poassword)
$servername ="sql7.freemysqlhosting.net";
$username ="sql7349027";
$password ="dHLfLuhjp8";
$dbname="sql7349027";

$connect = new mysqli ($servername,$username,$password,$dbname);


$plaka =$_POST["plaka"];

if (!empty($_POST["plaka"])) {


$eklee = "DELETE FROM arac_tbl WHERE plaka = '$plaka' ";
 if ($connect->query($eklee)) {
     echo "ARAÇ SİLME İŞLEMİ BAŞARILI...";
    
 }else {
    echo " Plaka Hatalı..."; 
 }
 }else {
     echo "Lütfen Alanları Doldurunuz"; 
 }
?>