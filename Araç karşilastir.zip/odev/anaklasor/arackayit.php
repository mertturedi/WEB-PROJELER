<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="\eklentiler\arackayit.css">
</head>
<body>




<div class="login-page">
    <form action="arackayitbaglanti.php" method ="Post">
    <div class ="kaydol">
 <p >ARAÇ KAYDET</p></div>
    
        <div class="form">
          <form class="login-form">
            <input type="text" placeholder="Marka" name = "marka"/>
            <input type="text" placeholder="Model" name="model"/>
            <input type="text" placeholder="Km" name="km"/>
            <input type="text" placeholder="Yıl" name="yil"/>
            <input type="text" placeholder="Renk" name="renk"/>
            <input type="text" placeholder="Plaka" name="plaka"/>
            <input type="text" placeholder="Araç Fiyatı" name="fiyat"/>
            <input type="file" placeholder="Resim" name="resim"/>
            <button>ARAÇ KAYDET</button>
            <p class="message">Anasayfaya<a href="anasayfa.php"> Dön</a></p>
            
            
          </form>
        </div>
        </form>



      </div>
</body>
</html>