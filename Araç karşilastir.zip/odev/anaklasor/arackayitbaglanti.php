<?php 


// Connection data (server_address, database, name, poassword)
$servername ="sql7.freemysqlhosting.net";
$username ="sql7349027";
$password ="dHLfLuhjp8";
$dbname="sql7349027";

$connect = new mysqli ($servername,$username,$password,$dbname);

$marka = $_POST["marka"];
$model =$_POST["model"];
$km =$_POST["km"];
$yil =$_POST["yil"];
$renk =$_POST["renk"];
$plaka =$_POST["plaka"];
$fiyat =$_POST["fiyat"];
$resim =$_POST["resim"];


if (!empty($_POST["marka"]) && !empty($_POST["model"])&& !empty($_POST["km"])&& !empty($_POST["yil"])&& !empty($_POST["renk"])&& !empty($_POST["plaka"])&& !empty($_POST["fiyat"])) {
$eklee = "INSERT INTO arac_tbl(marka,model,km,yil,renk,plaka,fiyat,resim) values ('$marka','$model','$km','$yil','$renk','$plaka','$fiyat','$resim')";
if ($connect->query($eklee)) {
    echo "kayıt yapıldı";
    header('Location: ./anasayfa.php');
    echo "
    <script type='text/javascript'>  
    alert('Lütfen Alanları Kontrol Ediniz Şifre Veya Mail Hatalı.');
    </script>";
    
}else {
   echo "kayıt hata"; 
}
}else {
    echo "Lütfen Alnları Doldurunuz"; 
 }

?>
