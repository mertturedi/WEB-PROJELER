<?php 


// Connection data (server_address, database, name, poassword)
$servername ="sql7.freemysqlhosting.net";
$username ="sql7349027";
$password ="dHLfLuhjp8";
$dbname="sql7349027";

$connect = new mysqli ($servername,$username,$password,$dbname);
if (!empty($_POST["AD"]) && !empty($_POST["SOYAD"])&& !empty($_POST["email"])&& !empty($_POST["sifre"])) {
$name = $_POST["AD"];
$surname =$_POST["SOYAD"];
$mail =$_POST["email"];
$pass =$_POST["sifre"];
$pass1 =$_POST["sifre2"];
if ($pass ==$pass1) {
   
$ekle = "INSERT INTO kayitol_tbl(adi,soyadi,mail,sifre) values ('$name','$surname','$mail','$pass')";
if ($connect->query($ekle)) {
    echo "kayıt yapıldı";
    header('Location: ./giris.php');
}else {
   echo "kayıt hata"; 
}
}else{

    echo "Şifreler Uyuşmuyor"; 
}
}
else{
    echo "Lütfen Alnları Doldurunuz"; 
}

?>