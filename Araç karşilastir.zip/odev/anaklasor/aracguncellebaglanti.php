<?php
  $servername ="sql7.freemysqlhosting.net";
  $username ="sql7349027";
  $password ="dHLfLuhjp8";
  $dbname="sql7349027";
  $connect = new mysqli ($servername,$username,$password,$dbname);

  $plaka =$_POST["plaka"];
  $fiyat =$_POST["fiyat"];
  $km =$_POST["km"];

  if (!empty($_POST["plaka"])&& !empty($_POST["fiyat"])&& !empty($_POST["km"])) {

    $eklee = "UPDATE arac_tbl set km='$km', fiyat='$fiyat'WHERE plaka='$plaka' ";
    if ($connect->query($eklee)) {
        echo "ARAÇ Güncellendi";
        
    }else {
       echo " HATA..."; 
    }
    }else {
        echo "Lütfen Alanları Doldurunuz"; 
     }
   
    ?>
